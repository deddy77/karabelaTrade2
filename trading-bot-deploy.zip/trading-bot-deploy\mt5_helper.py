import time
import pytz
import os
from datetime import datetime
import MetaTrader5 as mt5
import pandas as pd
from discord_notify import send_discord_notification
from config import (
    SYMBOL, TIMEFRAME, MAGIC_NUMBER, SLIPPAGE, LOG_FILE, SYMBOL_SETTINGS,
    MARKET_OPEN_DAY, MARKET_CLOSE_DAY, MARKET_OPEN_HOUR
)

# Map string timeframe to MT5 timeframe
TIMEFRAME_MAP = {
    "M1": mt5.TIMEFRAME_M1,
    "M5": mt5.TIMEFRAME_M5,
    "M15": mt5.TIMEFRAME_M15,
    "M30": mt5.TIMEFRAME_M30,
    "H1": mt5.TIMEFRAME_H1,
    "H4": mt5.TIMEFRAME_H4,
    "D1": mt5.TIMEFRAME_D1,
}

def connect():
    """Connect to MetaTrader 5 and enable auto-trading"""
    if not mt5.initialize():
        print(f"MT5 initialization failed. Error code: {mt5.last_error()}")
        return False
    
    if not mt5.account_info():
        print("No connection to trading account. Please login in MT5 first.")
        return False
    
    # Enable auto-trading if not already enabled
    terminal = mt5.terminal_info()
    if not terminal.trade_allowed:
        print("Auto-trading is disabled - attempting to enable...")
        mt5.terminal_info().trade_allowed = True
        if not mt5.terminal_info().trade_allowed:
            print("Failed to enable auto-trading - please enable manually in MT5 terminal")
            return False
    
    account_info = mt5.account_info()
    print(f"Connected to MT5 account: {account_info.login} ({account_info.server})")
    print(f"Balance: {account_info.balance}, Equity: {account_info.equity}")
    
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    
    return True

def shutdown():
    """Shutdown connection to MetaTrader 5"""
    mt5.shutdown()
    print("MT5 connection closed.")

def get_historical_data(symbol=SYMBOL, timeframe=TIMEFRAME, bars_count=100):
    """Get historical price data"""
    mt5_timeframe = TIMEFRAME_MAP.get(timeframe, mt5.TIMEFRAME_M5)
    
    # Get current time and fetch data relative to now
    current_time = datetime.now()
    rates = mt5.copy_rates_from(symbol, mt5_timeframe, current_time, bars_count)
    if rates is None or len(rates) == 0:
        print(f"Failed to get historical data for {symbol}")
        return None
    
    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s')
    
    utc_tz = pytz.timezone('UTC')
    est_tz = pytz.timezone('US/Eastern')
    df['time'] = df['time'].dt.tz_localize(utc_tz).dt.tz_convert(est_tz)
    df['time'] = df['time'].dt.tz_localize(None)
    return df

def check_market_conditions(symbol=SYMBOL):
    """Check if market is suitable for trading"""
    if not mt5.terminal_info().connected:
        print("⚠️ MT5 not connected!")
        return False
    
    # Check market hours (Sunday 5PM to Friday 5PM EST)
    now = datetime.now()
    est_tz = pytz.timezone('US/Eastern')
    est_time = est_tz.localize(now)
    
    # Friday after 5PM
    if est_time.weekday() == MARKET_CLOSE_DAY and est_time.hour >= MARKET_OPEN_HOUR:
        print("⚠️ Markets closed (Friday after 5PM EST)")
        return False
    # Saturday
    elif est_time.weekday() == 5:
        print("⚠️ Markets closed (Saturday)")
        return False
    # Sunday before 5PM
    elif est_time.weekday() == MARKET_OPEN_DAY and est_time.hour < MARKET_OPEN_HOUR:
        print("⚠️ Markets closed (Sunday before 5PM EST)")
        return False
    
    symbol_info = mt5.symbol_info(symbol)
    print(f"Current spread for {symbol}: {symbol_info.spread} points")
    if not symbol_info:
        print(f"⚠️ Failed to get {symbol} info")
        return False
    
    # Get symbol-specific spread limit
    max_spread = SYMBOL_SETTINGS[symbol].get("MAX_SPREAD", 20)  # Default to 20 if not specified
    
    if symbol_info.spread > max_spread:
        print(f"⚠️ Spread too wide for {symbol}: {symbol_info.spread} points")
        return False
    
    if not symbol_info.trade_mode == mt5.SYMBOL_TRADE_MODE_FULL:
        print(f"⚠️ Market not open for trading {symbol}")
        return False
    
    return True

def prepare_order_request(symbol, order_type, lot_size, price, sl, tp):
    """Prepare the order request with proper filling mode"""
    symbol_info = mt5.symbol_info(symbol)
    if not symbol_info:
        print(f"Failed to get symbol info for {symbol}")
        return None
        
    print(f"Symbol info for {symbol} - Digits: {symbol_info.digits}, Point: {symbol_info.point}")
    print(f"Trade modes - Filling: {symbol_info.filling_mode}, Execution: {symbol_info.trade_mode}")
    
    # Convert SL/TP - keep 0.0 only if no pips were provided
    sl = float(sl) if sl is not None else 0.0
    tp = float(tp) if tp is not None else 0.0
    
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": float(lot_size),
        "type": order_type,
        "price": price,
        "sl": sl,
        "tp": tp,
        "deviation": SLIPPAGE,
        "magic": MAGIC_NUMBER,
        "comment": "python-bot",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    
    print(f"Order request details for {symbol}:")
    print(f"Price: {price}, SL: {sl}, TP: {tp}")
    print(f"Volume: {lot_size}, Type: {order_type}")
    
    return request

def open_buy_order(symbol=SYMBOL, lot=None, stop_loss_pips=None, take_profit_pips=None, max_retries=3):
    """Open a buy position with proper error handling and dynamic risk management"""
    # If lot size is not specified, use minimum 0.01 as fallback
    if lot is None:
        print("⚠️ No lot size provided! Using minimum 0.01")
        lot = 0.01
    # Use dynamic stop loss/take profit if provided, otherwise fall back to symbol settings
    
    if stop_loss_pips is None:
        print("❌ No stop-loss provided! Using 20 pips default")
        stop_loss_pips = 20
    
    if not check_market_conditions(symbol):
        print(f"❌ Buy order aborted for {symbol} - bad market conditions")
        return False

    symbol_info = mt5.symbol_info(symbol)
    if not symbol_info:
        print(f"Failed to get symbol info for {symbol}")
        return False

    if not symbol_info.select:
        if not mt5.symbol_select(symbol, True):
            print(f"Failed to select {symbol}")
            return False

    point = symbol_info.point
    digits = symbol_info.digits
    
    # First check if we already have a buy position - avoid duplicate orders
    if has_buy_position(symbol):
        print(f"✅ BUY position already exists for {symbol}, skipping new order")
        return True
    
    for attempt in range(max_retries):
        try:
            tick = mt5.symbol_info_tick(symbol)
            if not tick:
                print(f"Failed to get current price for {symbol}")
                time.sleep(1)
                continue

            price = tick.ask
            pip_value = point * (10 if not symbol.endswith("JPY") else 1)  # Adjust for JPY pairs
            
            # Calculate SL/TP prices - ensure we don't pass 0.0 if pips are provided
            take_profit = round(price + (take_profit_pips * pip_value), digits) if take_profit_pips is not None else 0.0
            stop_loss = round(price - (stop_loss_pips * pip_value), digits) if stop_loss_pips is not None else 0.0
            
            # If TP pips were provided but calculation resulted in 0.0, log warning
            if take_profit_pips is not None and take_profit == 0.0:
                print(f"⚠️ Warning: TP calculation resulted in 0.0 despite {take_profit_pips} pips provided")

            request = prepare_order_request(
                symbol=symbol,
                order_type=mt5.ORDER_TYPE_BUY,
                lot_size=lot,
                price=price,
                sl=stop_loss,
                tp=take_profit
            )
            
            # Rest of the function remains the same...
            # [Keep all the existing order check and execution logic]
            
            if request is None:
                print(f"Failed to prepare order request for {symbol}")
                continue

            check = mt5.order_check(request)
            print(f"\nOrder check results for {symbol}:")
            print(f"Retcode: {check.retcode}")
            print(f"Balance: {check.balance}")
            print(f"Equity: {check.equity}")
            print(f"Margin: {check.margin}")
            print(f"Margin Free: {check.margin_free}")
            
            if check.retcode == 0:  # TRADE_RETCODE_DONE (success)
                result = mt5.order_send(request)
                print(f"\nOrder send results for {symbol}:")
                print(f"Retcode: {result.retcode}")
                print(f"Description: {result.comment}")
                
                # Wait a moment for the order to process
                time.sleep(0.5)
                
                # Check if the position was actually opened, regardless of the return code
                if has_buy_position(symbol):
                    print(f"✅ BUY order executed for {symbol} at {price} (SL: {stop_loss}, TP: {take_profit})")
                    log_trade(f"OPENED BUY: {lot} lot(s) of {symbol} at {price}")
                    send_discord_notification(f"🟢 BUY SIGNAL: {symbol} - {lot} lot(s) at {price}")
                    return True
                else:
                    # Only retry if we don't have a position and the return code indicated failure
                    if result.retcode != 0:
                        print(f"Order send failed for {symbol} with code: {result.retcode}")
                        print(f"Message: {result.comment}")
                    else:
                        # This is unexpected - success code but no position
                        print(f"Warning: Order returned success code but no position was detected for {symbol}")
            else:
                print(f"Order check failed for {symbol} with code: {check.retcode}")
                print(f"Message: {check.comment}")
            
            # Check again before retrying - position might have been opened despite errors
            if has_buy_position(symbol):
                print(f"✅ BUY position detected for {symbol} after attempted order, no need to retry")
                log_trade(f"OPENED BUY: {lot} lot(s) of {symbol} at {price}")
                return True
                
            time.sleep(1)

        except Exception as e:
            print(f"Error during buy order for {symbol}: {str(e)}")
            # Check if position was opened despite the exception
            if has_buy_position(symbol):
                print(f"✅ BUY position detected for {symbol} despite error, no need to retry")
                return True
            time.sleep(1)
    
    # Final check in case position was opened in the last attempt
    if has_buy_position(symbol):
        print(f"✅ BUY position detected for {symbol} after all attempts")
        return True
        
    print(f"❌ All buy order attempts failed for {symbol}")
    return False

def open_sell_order(symbol=SYMBOL, lot=None, stop_loss_pips=None, take_profit_pips=None, max_retries=3):
    """Open a sell position with proper error handling and dynamic risk management"""
    # If lot size is not specified, use minimum 0.01 as fallback
    if lot is None:
        print("⚠️ No lot size provided! Using minimum 0.01")
        lot = 0.01
        
    # Use dynamic stop loss/take profit if provided, otherwise fall back to symbol settings
    
    if stop_loss_pips is None:
        print("❌ No stop-loss provided! Using 20 pips default")
        stop_loss_pips = 20
    
    if not check_market_conditions(symbol):
        print(f"❌ Sell order aborted for {symbol} - bad market conditions")
        return False

    symbol_info = mt5.symbol_info(symbol)
    if not symbol_info:
        print(f"Failed to get symbol info for {symbol}")
        return False

    if not symbol_info.select:
        if not mt5.symbol_select(symbol, True):
            print(f"Failed to select {symbol}")
            return False

    point = symbol_info.point
    digits = symbol_info.digits
    
    # First check if we already have a sell position - avoid duplicate orders
    if has_sell_position(symbol):
        print(f"✅ SELL position already exists for {symbol}, skipping new order")
        return True
    
    for attempt in range(max_retries):
        try:
            tick = mt5.symbol_info_tick(symbol)
            if not tick:
                print(f"Failed to get current price for {symbol}")
                time.sleep(1)
                continue

            price = tick.bid
            pip_value = point * (10 if not symbol.endswith("JPY") else 1)  # Adjust for JPY pairs
            
            # Calculate SL/TP prices - ensure we don't pass 0.0 if pips are provided
            take_profit = round(price - (take_profit_pips * pip_value), digits) if take_profit_pips is not None else 0.0
            stop_loss = round(price + (stop_loss_pips * pip_value), digits) if stop_loss_pips is not None else 0.0
            
            # If TP pips were provided but calculation resulted in 0.0, log warning
            if take_profit_pips is not None and take_profit == 0.0:
                print(f"⚠️ Warning: TP calculation resulted in 0.0 despite {take_profit_pips} pips provided")

            print(f"Calculated TP price: {take_profit} (from {take_profit_pips} pips)")
            print(f"Calculated SL price: {stop_loss} (from {stop_loss_pips} pips)")
            
            request = prepare_order_request(
                symbol=symbol,
                order_type=mt5.ORDER_TYPE_SELL,
                lot_size=lot,
                price=price,
                sl=stop_loss,
                tp=take_profit
            )
            
            # Rest of the function remains the same...
            # [Keep all the existing order check and execution logic]
            
            if request is None:
                print(f"Failed to prepare order request for {symbol}")
                continue

            check = mt5.order_check(request)
            print(f"\nOrder check results for {symbol}:")
            print(f"Retcode: {check.retcode}")
            print(f"Balance: {check.balance}")
            print(f"Equity: {check.equity}")
            print(f"Margin: {check.margin}")
            print(f"Margin Free: {check.margin_free}")
            
            if check.retcode == 0:  # TRADE_RETCODE_DONE (success)
                result = mt5.order_send(request)
                print(f"\nOrder send results for {symbol}:")
                print(f"Retcode: {result.retcode}")
                print(f"Description: {result.comment}")
                
                # Wait a moment for the order to process
                time.sleep(0.5)
                
                # Check if the position was actually opened, regardless of the return code
                if has_sell_position(symbol):
                    print(f"✅ SELL order executed for {symbol} at {price} (SL: {stop_loss}, TP: {take_profit})")
                    log_trade(f"OPENED SELL: {lot} lot(s) of {symbol} at {price}")
                    send_discord_notification(f"🔴 SELL SIGNAL: {symbol} - {lot} lot(s) at {price}")
                    return True
                else:
                    # Only retry if we don't have a position and the return code indicated failure
                    if result.retcode != 0:
                        print(f"Order send failed for {symbol} with code: {result.retcode}")
                        print(f"Message: {result.comment}")
                    else:
                        # This is unexpected - success code but no position
                        print(f"Warning: Order returned success code but no position was detected for {symbol}")
            else:
                print(f"Order check failed for {symbol} with code: {check.retcode}")
                print(f"Message: {check.comment}")
            
            # Check again before retrying - position might have been opened despite errors
            if has_sell_position(symbol):
                print(f"✅ SELL position detected for {symbol} after attempted order, no need to retry")
                log_trade(f"OPENED SELL: {lot} lot(s) of {symbol} at {price}")
                return True
                
            time.sleep(1)

        except Exception as e:
            print(f"Error during sell order for {symbol}: {str(e)}")
            # Check if position was opened despite the exception
            if has_sell_position(symbol):
                print(f"✅ SELL position detected for {symbol} despite error, no need to retry")
                return True
            time.sleep(1)
    
    # Final check in case position was opened in the last attempt
    if has_sell_position(symbol):
        print(f"✅ SELL position detected for {symbol} after all attempts")
        return True
        
    print(f"❌ All sell order attempts failed for {symbol}")
    return False

def close_positions_by_type(symbol=SYMBOL, position_type=None):
    """Close positions of specific type (buy/sell) for the given symbol"""
    if position_type not in [mt5.ORDER_TYPE_BUY, mt5.ORDER_TYPE_SELL]:
        print(f"Invalid position type specified: {position_type}")
        return False
        
    positions = mt5.positions_get(symbol=symbol)
    
    if positions is None or len(positions) == 0:
        return True
    
    for position in positions:
        if position.magic != MAGIC_NUMBER or position.type != position_type:
            continue
            
        close_type = mt5.ORDER_TYPE_SELL if position.type == mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(symbol).bid if position.type == mt5.ORDER_TYPE_BUY else mt5.symbol_info_tick(symbol).ask
        
        request = prepare_order_request(
            symbol=symbol,
            order_type=close_type,
            lot_size=position.volume,
            price=price,
            sl=0,  # No SL/TP for closing orders
            tp=0
        )
        
        if request is None:
            continue

        request["position"] = position.ticket
        result = mt5.order_send(request)
        
        if result.retcode != 0:
            error_msg = f"Close position failed for {symbol}. Error code: {result.retcode}"
            print(error_msg)
            log_trade(f"ERROR: {error_msg}")
            return False
        
        type_str = "BUY" if position.type == mt5.ORDER_TYPE_BUY else "SELL"
        success_msg = f"Closed {type_str} position: {position.volume} lot(s) of {symbol} at {price}"
        print(success_msg)
        log_trade(f"CLOSED {type_str}: {success_msg}")
        send_discord_notification(f"🟠 CLOSED {type_str}: {position.volume} lot(s) of {symbol} at {price}")
    
    return True

def close_all_positions(symbol=SYMBOL):
    """Close all positions for the given symbol"""
    # Close buy positions first
    if not close_positions_by_type(symbol, mt5.ORDER_TYPE_BUY):
        return False
    # Then close sell positions
    return close_positions_by_type(symbol, mt5.ORDER_TYPE_SELL)

def get_open_positions(symbol=SYMBOL):
    """Get all open positions for the given symbol"""
    positions = mt5.positions_get(symbol=symbol)
    return [] if positions is None else [pos for pos in positions if pos.magic == MAGIC_NUMBER]

def has_buy_position(symbol=SYMBOL):
    """Check if there is an open buy position"""
    positions = get_open_positions(symbol)
    return any(pos.type == mt5.ORDER_TYPE_BUY for pos in positions)

def has_sell_position(symbol=SYMBOL):
    """Check if there is an open sell position"""
    positions = get_open_positions(symbol)
    return any(pos.type == mt5.ORDER_TYPE_SELL for pos in positions)

def log_trade(message):
    """Log trade information to file"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a") as log_file:
        log_file.write(f"{timestamp} - {message}\n")
